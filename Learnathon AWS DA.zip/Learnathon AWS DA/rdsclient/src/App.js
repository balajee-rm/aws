import axios from 'axios'
import React, {useState} from 'react'

const Display = ({data}) => {
  if (data !== null) {
      return (
        <div>
          {data.map ((obj) => {
          console.log("obj = " + obj)
          return <p> id = {obj.id}, name = {obj.name} </p>
          })}
        </div>
      )
  }
  else {
    return "Loading"
  }
}

const LoginForm = () => {
  
  const [formValue, setformValue] = React.useState({
    id: '',
    name: ''
  });

  const handleSubmit = async() => {
  // store the states in the form data
  const loginFormData = new FormData();
  loginFormData.append("id", formValue.id)
  loginFormData.append("name", formValue.name)

  try {
    // make axios post request
    const response = await axios({
      method: "post",
      url: "http://65.0.169.181:8080/postsave/",
      data: loginFormData,
      headers: { "Content-Type": "multipart/form-data" },
    });
  } catch(error) {
    console.log(error)
  }
  }

  const handleChange = (event) => {
    setformValue({
      ...formValue,
      [event.target.name]: event.target.value
    });
  }

  return (
    <form onSubmit={handleSubmit}>
      <p>Login Form</p>
      <input
        type="test"
        name="id"
        placeholder="enter int id"
        value={formValue.id}
        onChange={handleChange}
      />
      <input
        type="text"
        name="name"
        placeholder="enter your name less than 10 char"
        value={formValue.name}
        onChange={handleChange}
      />
      <button
        type="submit"
      >
        Login
      </button>
    </form>
  )
};

const App = () => {
  const [data, setData] = useState (null);

  if(data === null) {
    axios.get(`http://65.0.169.181:8080/corsget/`)
    .then(res => {
      setData(res.data)
      console.log (res.data)
    })
  }

  return (
    <div>
      Page Running
      <br/>
      <LoginForm />
      <br/>
      <br/>
      <Display data = {data} />
    </div>
  )
}

export default App
