from django.contrib import admin
from .models import Sample

# Register your models here.
admin.site.register(Sample);
